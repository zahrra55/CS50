#include <stdio.h>
// this is my first c try
int main(void)
{
    printf("hello, world");
}
